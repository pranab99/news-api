
import axios, { Axios } from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import './App.css';
import { setNews, getNews } from './redux/actions/userNewsActions';
function App() {
  const dispatch = useDispatch();
  const news = useSelector(state=>state.news);
  console.log(news);
  // const apiKey="15adc9f22778491d9c2e7cf26bafa1a7"
  const baseUrl = "https://newsapi.org/v2/everything?q=apple&from=2022-06-30&to=2022-06-30&sortBy=popularity&apiKey=15adc9f22778491d9c2e7cf26bafa1a7"
  const getData=()=>{
    // dispatch(setNews({data:"News Data to show"}))
    dispatch(getNews())
  
  }
  return (
    <div className="App">
     <h1>Pranab here</h1>
     <button onClick={getData}>Wanna see the headline today?</button>
     {news?.name && (
       <h6>{news.name}</h6>
     )}
    
    </div>
  );
}

export default App;
