import { combineReducers } from "redux";
import userNewsReducer from './userNewsReducers'
export default combineReducers({
    news:userNewsReducer
})