const initialState={name:"Pranab Das"};
export default function reducer(state=initialState,action){
    switch(action.type){
        case "SET_NEWS_DATA":
            const news = action.payload;
            return {...state,...news};
        default: return state;
    }
}