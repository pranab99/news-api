//plain
export function getNews(){
    return {type:"GET_NEWS_DATA"}
}
export function setNews(news){
    return {
        type:"SET_NEWS_DATA",
        payload:news
    }
}