import { applyMiddleware, createStore } from "redux";
import reducer from "../redux/reducers";
import createSagaMiddleware from "redux-saga";
import sagaWatcher from "./sagas";

const sagaMiddleware = createSagaMiddleware();

const middlewares =[sagaMiddleware]

const store = createStore(reducer,{},applyMiddleware(...middlewares));
sagaMiddleware.run(sagaWatcher);
export default store;
