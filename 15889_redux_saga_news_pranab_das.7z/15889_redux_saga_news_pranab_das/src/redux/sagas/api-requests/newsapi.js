import axios from "axios"
const baseUrl = "https://newsapi.org/v2/everything?q=apple&from=2022-06-30&to=2022-06-30&sortBy=popularity&apiKey=15adc9f22778491d9c2e7cf26bafa1a7"
export default function getNewsDatafromAPI(){
    return axios.get(`${baseUrl}`)
}