//watcher
import { takeLatest } from 'redux-saga/effects'
import newsHandler from './handlers/newsHandler'
export default function* sagaWatcher(){
    yield takeLatest('GET_NEWS_DATA',newsHandler)
}