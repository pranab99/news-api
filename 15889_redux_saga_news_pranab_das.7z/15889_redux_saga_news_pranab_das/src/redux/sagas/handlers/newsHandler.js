import {call, put} from 'redux-saga/effects'
import { setNews } from '../../actions/userNewsActions';
import getNewsDatafromAPI from '../api-requests/newsapi'
export default function* newsHandler(){
    try {
        const response = yield call(getNewsDatafromAPI)
        const news=response.data;
        //dispatch and setdata
        yield put(setNews({news}))
    } catch (error) {
        console.log(error);
    }
    
  
}